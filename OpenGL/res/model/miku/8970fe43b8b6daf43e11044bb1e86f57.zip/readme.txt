  
  Kinsama式初音ミクV4C


  感谢人设作者： 豆の素（微博：https://weibo.com/amatsukiryoyu）

  版权所属： Crypton Future Media, INC.

  建模师：Kacha，Kinsama（微博：https://weibo.com/bakakin）

  贴图绘制：Ral


  这是我两年前制作的第一个模型，有些现在看起来不是很满意的地方，还是希望大家喜欢

  为避免不必要的麻烦，请不要将这个模型用于商业、政治、宗教、暴力、血腥、色情等敏感内容

  ---------------------------------

  Hatune Miku V4C

  Illustration by 豆の素（weibo：https://weibo.com/amatsukiryoyu）
 
  Copyright: Crypton Future Media, INC.

  Model by Kacha，Kinsama（weibo：https://weibo.com/bakakin）

  Textures by Ral


  This model was made two years before and is available to download now. I sincerely hope you will like her.

  This model forbid for commercial, politics, religion, violence, bloody, and r-18 use.